package com.Employee;

public class Employee {
    String name="shilpa";
    int age=21;
    String city="calicut";
    public void display(){
        System.out.println("The name is "+name);
        System.out.println("The age is "+age);
        System.out.println("The city is "+city);
    }
}
