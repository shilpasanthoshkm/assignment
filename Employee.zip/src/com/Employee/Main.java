package com.Employee;

public class Main {

    public static void main(String[] args) {
	Employee e=new Employee();
	Employee e1=new Employee();
	e.display();
    }
}
